from flask import Flask, render_template, jsonify, send_from_directory
from sqlalchemy import create_engine
import pandas as pd
import os

app = Flask(__name__)

# Ruta a los archivos adjuntos
ARCHIVOS_DIR = r"Z:\\"

# Configuración de conexión a PostgreSQL
user = 'jbpm'
password = 'jbpm'
host = 'localhost'
port = '5432'
database = 'jbpm'
engine = create_engine(f'postgresql+psycopg2://{user}:{password}@{host}:{port}/{database}')

# Ruta principal que carga la interfaz HTML
@app.route('/')
def index():
    return render_template('index.html')

# Endpoint para descarga de archivos
@app.route('/descargar/<filename>')
def descargar_archivo(filename):
    try:
        return send_from_directory(ARCHIVOS_DIR, filename, as_attachment=True)
    except FileNotFoundError:
        return f"<p style='color:red;'>Archivo no encontrado: {filename}</p>"

# Endpoint para generar y mostrar la tabla con botones de descarga
@app.route('/generar_tabla', methods=['GET'])
def generar_tabla():
    try:
        # Consulta de datos combinando taskvariableimpl y task
        consulta_sql = """
            SELECT
                task.actualowner_id,
                taskvariableimpl.name as campo,
                taskvariableimpl.value
            FROM taskvariableimpl
            JOIN task
                ON taskvariableimpl.processinstanceid = task.processinstanceid
                and taskvariableimpl.taskid = task.id
            WHERE taskvariableimpl.value LIKE %(patron)s
            ORDER BY taskvariableimpl.processinstanceid;
        """

        df = pd.read_sql(consulta_sql, engine, params={"patron": "%####%"})
        
        # Función para extraer el nombre base del archivo desde el campo 'value'
        def extraer_nombre_archivo(valor):
            if isinstance(valor, str) and '####' in valor:
                return valor.split('####')[0]
            return None

        # Generar HTML del botón de descarga si el archivo existe
        def generar_html_descarga(valor):
            nombre_archivo = extraer_nombre_archivo(valor)
            if nombre_archivo:
                ruta_archivo = os.path.join(ARCHIVOS_DIR, nombre_archivo)
                if os.path.isfile(ruta_archivo):
                    return f'<a href="/descargar/{nombre_archivo}" class="btn btn-sm btn-primary" target="_blank">{nombre_archivo}</a>'
            return valor  # En caso contrario, mostrar el valor original

        
        # Aplicar la transformación a la columna 'value'
        df['value'] = df['value'].apply(generar_html_descarga)

        # Guardar la tabla transformada en base de datos
        df.to_sql(
            name='x_mi_tabla_completa',
            con=engine,
            if_exists='replace',
            index=False
        )

        # Renderizar HTML
        nombre_tabla = "<h3>Tabla:</h3> <h1>x_mi_tabla_completa</h1><a> Se generó y almacenó en base de datos</a><hr>"
        tabla_html = df.to_html(classes='table table-bordered', index=False, escape=False)

        return jsonify({'tabla': nombre_tabla + tabla_html})

    except Exception as e:
        return jsonify({'tabla': f"<p style='color:red;'>Error al generar o almacenar la tabla: {e}</p>"})

if __name__ == '__main__':
    app.run(debug=True)
